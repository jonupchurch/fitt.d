/**
 * Scorers for the Fitt.d eval harness.
 *
 * Each scorer takes the pipeline output for a fixture plus that fixture's
 * expectations and returns a 0..1 score with a short note. Thresholds live in
 * run-evals.ts. Scorers never call the model — they judge output that already exists.
 */

export interface Expected {
  requiredSkills: string[];        // skills the JD truly requires
  unsupportedSkills: string[];     // skills that must NOT be reported as matched
  fitScore: { min: number; max: number };
  keywords: { mustCover: string[] };
}

export interface PipelineOutput {
  jd: { requiredSkills: string[]; atsKeywords: string[] };
  gap: {
    fitScore: number;
    matchedSkills: { skill: string; evidence?: string }[];
    keywordCoverage: { covered: string[]; missing: string[] };
  };
}

export interface ScoreResult { name: string; score: number; note: string; }

const norm = (s: string) => s.trim().toLowerCase();
const has = (arr: string[], s: string) => arr.map(norm).includes(norm(s));

export function requiredSkillRecall(out: PipelineOutput, exp: Expected): ScoreResult {
  const found = exp.requiredSkills.filter((s) => has(out.jd.requiredSkills, s));
  const score = exp.requiredSkills.length ? found.length / exp.requiredSkills.length : 1;
  return { name: "required_skill_recall", score, note: `${found.length}/${exp.requiredSkills.length} required skills surfaced` };
}

export function noHallucinatedMatches(out: PipelineOutput, exp: Expected): ScoreResult {
  const matched = out.gap.matchedSkills.map((m) => m.skill);
  const bad = exp.unsupportedSkills.filter((s) => has(matched, s));
  const noEvidence = out.gap.matchedSkills.filter((m) => !m.evidence).map((m) => m.skill);
  const violations = bad.length + noEvidence.length;
  return {
    name: "no_hallucinated_matches",
    score: violations === 0 ? 1 : 0,
    note: violations === 0 ? "no unsupported matches" : `violations: ${[...bad, ...noEvidence].join(", ")}`,
  };
}

export function scoreInBand(out: PipelineOutput, exp: Expected): ScoreResult {
  const { min, max } = exp.fitScore;
  const ok = out.gap.fitScore >= min && out.gap.fitScore <= max;
  return { name: "fit_score_plausible", score: ok ? 1 : 0, note: `got ${out.gap.fitScore}, expected ${min}–${max}` };
}

export function keywordCoverage(out: PipelineOutput, exp: Expected): ScoreResult {
  const covered = out.gap.keywordCoverage.covered;
  const hit = exp.keywords.mustCover.filter((k) => has(covered, k));
  const score = exp.keywords.mustCover.length ? hit.length / exp.keywords.mustCover.length : 1;
  return { name: "keyword_coverage", score, note: `${hit.length}/${exp.keywords.mustCover.length} expected keywords covered` };
}

export const SCORERS = [requiredSkillRecall, noHallucinatedMatches, scoreInBand, keywordCoverage];
