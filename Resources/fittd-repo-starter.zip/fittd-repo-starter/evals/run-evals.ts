/**
 * Fitt.d eval harness.
 *
 * Loads every fixture in ./fixtures, runs it through the analysis pipeline, applies
 * the scorers, prints a table, and exits non-zero if any metric is below threshold.
 *
 *   pnpm eval          # deterministic fake provider (CI default: free, no network)
 *   pnpm eval --live   # real model, for validating prompt changes before release
 *
 * The pipeline depends only on the LLMProvider interface (ADR-0005), so we inject a
 * fake provider here. Wire `createPipeline` / provider imports to your app once built.
 */
import { readdirSync, readFileSync, existsSync } from "node:fs";
import { join } from "node:path";
import { SCORERS, type Expected, type PipelineOutput } from "./scorers";

// TODO: import from the app once implemented:
//   import { createPipeline } from "../src/pipeline";
//   import { AnthropicProvider } from "../src/llm/anthropic";
//   import { FakeProvider } from "../src/llm/fake";

const THRESHOLDS: Record<string, number> = {
  required_skill_recall: 0.8,
  no_hallucinated_matches: 1.0,
  fit_score_plausible: 1.0,
  keyword_coverage: 0.7,
};

const FIXTURES_DIR = join(__dirname, "fixtures");
const live = process.argv.includes("--live");

async function runFixture(name: string): Promise<PipelineOutput> {
  const dir = join(FIXTURES_DIR, name);
  const resume = readFileSync(join(dir, "resume.md"), "utf8");
  const jd = readFileSync(join(dir, "job-description.md"), "utf8");

  // const provider = live ? new AnthropicProvider() : new FakeProvider(dir);
  // const pipeline = createPipeline(provider);
  // return pipeline.analyze({ resume, jd });

  void resume; void jd; void live;
  throw new Error("Wire createPipeline() + provider imports to run. Fixtures and scorers are ready.");
}

async function main() {
  const fixtures = readdirSync(FIXTURES_DIR, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => d.name);

  let failed = false;
  const rows: string[] = [];

  for (const name of fixtures) {
    const expPath = join(FIXTURES_DIR, name, "expected.json");
    if (!existsSync(expPath)) continue;
    const expected = JSON.parse(readFileSync(expPath, "utf8")) as Expected;

    const output = await runFixture(name);
    for (const scorer of SCORERS) {
      const r = scorer(output, expected);
      const pass = r.score >= (THRESHOLDS[r.name] ?? 1);
      if (!pass) failed = true;
      rows.push(`${pass ? "PASS" : "FAIL"}  ${name.padEnd(18)} ${r.name.padEnd(24)} ${r.score.toFixed(2)}  ${r.note}`);
    }
  }

  console.log(rows.join("\n"));
  console.log(failed ? "\nEVAL FAILED" : "\nEVAL PASSED");
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(1); });
