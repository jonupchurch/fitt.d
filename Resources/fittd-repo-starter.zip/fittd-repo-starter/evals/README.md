# Evals

Most portfolios call an LLM and hope. This one **measures** it. The eval harness runs a set of realistic resume/JD fixtures through the analysis pipeline and scores the output against expectations — so a prompt change that quietly makes results worse gets caught, in CI, before it ships.

## What it checks

Each fixture is scored on:

- **Schema validity** — every structured response parses against its Zod schema (the ADR-0002 contract).
- **Required-skill recall** — of the skills we know the JD requires, how many did JD-analysis surface?
- **No hallucinated skills** — matched skills must have resume evidence; flag any "match" the fixture says isn't supported.
- **Score plausibility** — the fit score lands within the fixture's expected band (a strong-match resume shouldn't score 30; a weak one shouldn't score 90).
- **Keyword coverage sanity** — covered/missing keyword split matches expectations within tolerance.

The run prints a per-fixture table and **exits non-zero if any metric falls below its threshold**, so `pnpm eval` is a real CI gate.

## Running

```bash
pnpm eval            # against the fake provider (deterministic, free, no network)
pnpm eval --live     # against the real model (costs tokens; run before prompt releases)
```

The fake provider (injected via the `LLMProvider` interface, ADR-0005) returns fixed responses so the harness itself is testable and CI stays free and deterministic. `--live` swaps in the real provider to validate prompt changes.

## Adding a fixture

Create `fixtures/<name>/` with:
- `resume.md` — a realistic resume.
- `job-description.md` — a realistic JD.
- `expected.json` — the ground-truth expectations (see existing fixtures for the shape).

Aim for variety: strong match, partial match, career-changer, over-qualified. Fixtures pull triple duty — eval inputs, demo data, and E2E test data.
