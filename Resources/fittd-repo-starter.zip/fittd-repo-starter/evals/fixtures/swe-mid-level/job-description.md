# Senior Frontend Engineer — Northwind

We're hiring a Senior Frontend Engineer to own our design-system and core app UI.

## Requirements
- 5+ years of frontend engineering experience
- Expert in React and TypeScript
- Strong experience with Next.js and server-side rendering
- Deep understanding of web accessibility (WCAG)
- Experience building and maintaining a component/design system

## Nice to have
- Experience with GraphQL
- Familiarity with testing (Jest, Playwright)
- Design tooling (Figma)

## Responsibilities
- Lead frontend architecture for the core product
- Build and evolve the shared component library
- Mentor mid-level engineers
