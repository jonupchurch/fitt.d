# Jordan Alvarez
Full-Stack Software Engineer · jordan.alvarez@example.com · Cleveland, OH

## Summary
Full-stack engineer with 4 years building web apps in React and Node. Comfortable across the stack, from Postgres schemas to accessible UI.

## Skills
JavaScript, TypeScript, React, Node.js, Express, PostgreSQL, REST APIs, Jest, Git, Docker, AWS (basic)

## Experience

### Software Engineer — Brightloom (2022–present)
- Built customer-facing dashboard in React and TypeScript used by 12k monthly users.
- Designed and shipped REST APIs in Node/Express backed by PostgreSQL.
- Added Jest unit tests, raising coverage on the billing module from 40% to 85%.
- Containerized the app with Docker and set up staging deploys.

### Junior Developer — Marlin Web (2020–2022)
- Implemented responsive marketing pages from Figma designs.
- Fixed accessibility issues to meet WCAG AA on the main funnel.

## Education
B.S. Computer Science, Ohio State University, 2020
