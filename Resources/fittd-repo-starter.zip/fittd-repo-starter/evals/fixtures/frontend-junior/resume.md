# Priya Nair
Frontend Developer · priya.nair@example.com

## Summary
Recent bootcamp graduate building small web apps. Eager to grow into a React role.

## Skills
HTML, CSS, JavaScript, jQuery, Bootstrap, Git, basic React

## Experience

### Freelance Web Developer (2023–present)
- Built five small-business websites with HTML, CSS, and jQuery.
- Created one to-do app in React following a tutorial.

### Retail Associate — Cityline (2019–2023)
- Trained new staff and managed inventory.

## Education
Full-Stack Web Development Bootcamp, 2023
