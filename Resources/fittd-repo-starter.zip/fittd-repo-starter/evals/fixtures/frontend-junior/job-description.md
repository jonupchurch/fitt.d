# Frontend Engineer — Cadence Health

## Requirements
- 3+ years professional experience with React and TypeScript
- Experience consuming REST APIs
- Solid testing habits (Jest or similar)
- Understanding of accessible, responsive UI

## Nice to have
- Next.js
- Experience in a healthcare or regulated environment
