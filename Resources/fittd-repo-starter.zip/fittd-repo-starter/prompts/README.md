# Prompts

Prompts are product IP, so they're treated like code: **versioned files, not inline strings.**

## Rules

- One file per task, named `<task>.v<N>.md`. The current version is imported by the pipeline; older versions stay for diffing and eval comparison.
- Each prompt declares its `model`, `temperature`, and the **output schema** it must satisfy (the Zod schema of the same name is the source of truth — ADR-0002).
- A behavior change = a **new version** (`v2`), never an in-place edit. Evals (see `../evals`) pin a version so results are reproducible.
- Prompts are provider-agnostic (ADR-0005) — no vendor-specific syntax leaks in.

## Tasks

| File | Purpose | Output schema |
|---|---|---|
| `jd-analysis.v1.md` | Extract structure from a job description | `JDAnalysis` |
| `resume-parse.v1.md` | Parse a resume into structured sections | `ResumeParse` |
| `gap-analysis.v1.md` | Compare resume vs. JD → score + gaps | `GapAnalysis` |
| `bullet-tailoring.v1.md` | Rewrite bullets to close the gap (streamed) | prose (streamed) |
