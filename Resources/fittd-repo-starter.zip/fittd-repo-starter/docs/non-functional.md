# Non-functional requirements & budgets

The functional spec says *what* Fitt.d does; this says *how well* it has to do it. These are the targets the implementation is held to, and several are asserted in tests/CI.

## Performance

| Metric | Target |
|---|---|
| Time to first streamed token | < 2s (p50) |
| Full analysis complete | < ~15s (p90) |
| Interaction responsiveness | no blocking main-thread work > 50ms |

The streaming/skeleton split (ADR-0004) exists to hit the *perceived* side of these targets even when the model is slow.

## Cost

- Log token count + estimated cost **per request** (`FITTD_LOG_USAGE`).
- Target **~$0.0X per analysis**; the repair-retry (ADR-0002) is capped so a bad response can't multiply cost.
- Surface a running cost figure in the README once measured — it demonstrates production/business awareness.

## Limits & abuse

| Guard | Default | Why |
|---|---|---|
| Max resume size | 20,000 chars | bounds cost/latency; rejects pasted PDFs of a whole portfolio |
| Max JD size | 12,000 chars | same |
| Rate limit | 6 requests/min per IP | abuse control without accounts (ADR-0006) |

Over-limit inputs get a clear, actionable error (see `content/microcopy.md`), never a silent truncation.

## Accessibility

- WCAG 2.1 **AA** contrast (note the cyan-vs-white button rule in the brand guide).
- Full keyboard operability; visible focus states (brand cyan focus ring).
- `prefers-reduced-motion` respected for the streaming/skeleton animations.

## Reliability & observability

- Every model call is validated (ADR-0002); invalid output degrades to a typed error, never a broken UI.
- Structured logs: request id, phase, latency, tokens, cost, outcome — **no PII** (ADR-0003).

## Compatibility

- Latest 2 versions of evergreen browsers; responsive down to 360px width.
