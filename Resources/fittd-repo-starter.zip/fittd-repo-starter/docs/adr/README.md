# Architecture Decision Records

Each ADR captures one decision that had a real tradeoff: the context, the choice, the alternatives we rejected, and the consequences we accepted. They're the "why" behind the code — read alongside the Spec Kit plan.

Format: lightweight [MADR](https://adr.github.io/madr/). Status is one of `Proposed`, `Accepted`, `Superseded by ADR-XXXX`.

| # | Decision | Status |
|---|---|---|
| [0001](0001-record-architecture-decisions.md) | Record architecture decisions | Accepted |
| [0002](0002-llm-output-validation-and-retries.md) | Validate LLM output with Zod + repair-retry | Accepted |
| [0003](0003-ephemeral-processing-no-persistence.md) | Process inputs in memory; persist nothing | Accepted |
| [0004](0004-response-streaming-strategy.md) | Stream prose, block on validated JSON | Accepted |
| [0005](0005-model-provider-abstraction.md) | Abstract the model provider behind an interface | Accepted |
| [0006](0006-auth-strategy-mvp.md) | No auth for MVP | Accepted |

New decision? Copy `0000-template.md`.
