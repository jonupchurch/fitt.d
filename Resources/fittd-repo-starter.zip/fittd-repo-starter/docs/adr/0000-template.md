# ADR-XXXX: <short decision title>

- **Status:** Proposed
- **Date:** YYYY-MM-DD
- **Deciders:** <you>

## Context

What forces are at play? What problem or constraint requires a decision? Keep it factual — the situation, not the solution.

## Decision

The choice we're making, stated in one or two sentences, in active voice: "We will …".

## Alternatives considered

- **Option A** — pros / cons, and why not.
- **Option B** — pros / cons, and why not.

## Consequences

What becomes easier, and what we accept as the cost. Include follow-ups this decision creates.
