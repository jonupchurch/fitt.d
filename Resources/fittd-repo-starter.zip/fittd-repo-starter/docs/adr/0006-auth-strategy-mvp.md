# ADR-0006: No authentication for the MVP

- **Status:** Accepted
- **Date:** 2026-01-01
- **Deciders:** <you>

## Context

Accounts add friction (the biggest drop-off point for a portfolio demo is anything before the value) and only earn their keep once there's per-user data to protect. Under ADR-0003 there is no persisted user data in the MVP.

## Decision

We will ship the MVP with **no auth and no accounts**: anyone can run an analysis anonymously. Abuse is bounded by per-IP rate limiting (see `docs/non-functional.md`) rather than login.

## Alternatives considered

- **Auth from day one** — necessary later for saved history, but here it only adds friction and a login screen between the reviewer and the demo.
- **Optional/"guest" auth** — extra surface for no MVP payoff; deferred.

## Consequences

A hiring manager reaches the core value in seconds with zero signup. When saved history and multiple resume versions land (roadmap), this decision is revisited together with ADR-0003, and auth is introduced then.
