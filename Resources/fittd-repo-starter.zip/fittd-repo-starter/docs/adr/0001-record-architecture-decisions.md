# ADR-0001: Record architecture decisions

- **Status:** Accepted
- **Date:** 2026-01-01
- **Deciders:** <you>

## Context

Fitt.d is a portfolio project whose repository is itself the deliverable — a reviewer should be able to see not just *what* was built but *why* it was built that way. Design and styling guides capture intent; they don't capture the decisions that had alternatives.

## Decision

We will record every architecturally significant decision as a numbered ADR in `docs/adr/`, using lightweight MADR. A decision is "significant" if it constrains future work, is hard to reverse, or a reasonable engineer would ask "why did you do it this way?"

## Alternatives considered

- **Inline comments / commit messages only** — cheap, but decisions get buried and lose their rationale over time.
- **A single design doc** — becomes stale and unstructured; no clear per-decision status or supersession trail.

## Consequences

Decisions are reviewable in isolation and linkable from the README and Spec Kit plan. Small ongoing cost: writing a short ADR when a real tradeoff is made. Superseded decisions stay in history rather than being deleted.
