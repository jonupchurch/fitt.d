# ADR-0005: Abstract the model provider behind an interface

- **Status:** Accepted
- **Date:** 2026-01-01
- **Deciders:** <you>

## Context

The product calls an LLM in several places. Hard-wiring a specific vendor SDK throughout the codebase makes the model impossible to swap, hard to mock in tests, and couples business logic to a vendor's response shape.

## Decision

We will define a thin `LLMProvider` interface — `generateStructured(schema, prompt)`, `stream(prompt)` — and depend only on that interface in application code. The default implementation targets the Anthropic API; the concrete provider and model are chosen from env (`FITTD_MODEL`). Prompts live as versioned files (`prompts/`) independent of any provider.

## Alternatives considered

- **Call the vendor SDK directly everywhere** — least code now, but vendor lock-in and untestable business logic; a poor signal for an "architect" portfolio.
- **A heavyweight adapter framework** — overkill for one provider; the interface only needs the two operations we actually use.

## Consequences

The provider is a config change, business logic is model-agnostic, and tests/evals can inject a deterministic fake provider (no network, no cost). Small ongoing cost: new capabilities must be added to the interface deliberately rather than reaching for a vendor-specific feature ad hoc.
