# ADR-0004: Stream prose; block on validated JSON

- **Status:** Accepted
- **Date:** 2026-01-01
- **Deciders:** <you>

## Context

Full analysis can take several seconds. A blank spinner for the whole duration feels broken, but the structured results (scores, skill lists) can't be shown until they're complete and validated (ADR-0002) — a half-streamed score is worse than a skeleton.

## Decision

We will use a **hybrid** response model. Human-readable, additive content (tailored bullets, summary rewrite, cover-letter starter) **streams token-by-token** so the UI feels alive immediately. Structured, must-be-correct content (fit score, matched/missing skills, keyword coverage) is **rendered only after its schema validates**, with a skeleton placeholder until then. Delivered from a Next.js route handler over a streaming response.

## Alternatives considered

- **Stream everything, including JSON** — visually flashy but shows partial/invalid structured data mid-stream, which can mislead; conflicts with ADR-0002.
- **Block on everything** — simplest, but a multi-second dead spinner reads as slow and is the weakest possible demo moment.

## Consequences

Perceived latency drops sharply where it matters (the demo feels fast) while correctness is preserved for the numbers. Cost: two rendering paths and a slightly more involved client state machine (streaming vs. skeleton-then-swap). The distinction is documented so the UI states in `content/microcopy.md` map cleanly to it.
