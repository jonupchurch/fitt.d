# ADR-0003: Process inputs in memory; persist nothing

- **Status:** Accepted
- **Date:** 2026-01-01
- **Deciders:** <you>

## Context

Resumes and job descriptions are personal data — often containing names, contact details, and employment history. Storing them creates real obligations (security, retention, deletion, consent) and a breach surface, for a product whose MVP value doesn't require history.

## Decision

We will process resume and JD content **in memory for the duration of a single request** and persist none of it — no database of inputs, no raw content in logs, no use for model training. The only data retained is **anonymous, aggregate telemetry**: latency, token count, estimated cost, and match-score distribution, with no input text attached.

## Alternatives considered

- **Store inputs to enable history/accounts** — a real feature, but it pulls auth, a datastore, retention policy, and compliance into the MVP. Deferred to the roadmap.
- **Store hashed/truncated inputs for debugging** — still PII risk for marginal benefit; rejected. We debug from anonymized telemetry and eval fixtures instead.

## Consequences

Strong, honest privacy story that doubles as a landing-page selling point (see `docs/privacy.md`), and a much smaller compliance and security surface. Cost: no saved history or multi-version compare in MVP; those require revisiting this decision alongside ADR-0006 (auth).
